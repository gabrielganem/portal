1- This Module support?
	* This is a Module for joomla 2.5 and 3.x
	* BM Cool Menu help you show menu with many configs for color. You can config almost color on menu (text, background, active background, border). Visit our website <a href='http://www.brainymore.com' target='_blank'>Brainymore.com</a> to see our new products.
	* Select Menu: Select a menu in the list
	* Start Level: Level to start rendering the menu at. Setting the start and end levels to the same # and setting 'Show Sub-menu Items' to yes will only display that single level.
	* End Level: Level to stop rendering the menu at. If you choose 'All', all levels will be shown depending on 'Show Sub-menu Items' setting.
	* Show Sub-menu Items: Expand the menu and make its sub-menu items always visible
	* Text color: Color for text
	* Hover text color: Color for text when hover menu item
	* Menu's background: Background for menu
	* Background image: You can config css (background-image) for menu. <br> Fomart:<br>
background-image: -moz-linear-gradient(#2B547E, #2B3856);<br> 
background-image: -webkit-gradient(linear, left top, left bottom, from(#2B547E), to(#2B3856));<br>	
background-image: -webkit-linear-gradient(#2B547E, #2B3856);<br>	
background-image: -o-linear-gradient(#2B547E, #2B3856);<br>
background-image: -ms-linear-gradient(#2B547E, #2B3856);<br>
background-image: linear-gradient(#2B547E, #2B3856);
	* Show border: Show border or not
	* Border radius: Config border radius (1px,2px ...)
	* Border color: Set color for border
	* Active background: Background color for active item
	* Load jQuery: Load jQuery or not
	
	* Brainymore! Official site: http://www.brainymore.com
	* Detailed changes in the Changelog: 
Copyright:
	* Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.
	* Distributed under the GNU General Public License version 2 or later
	* See Licenses details at LICENSE.txt
